`timescale 1ns / 1ps

module GrayScaleFilter (
    input  wire [3:0] i_r,
    input  wire [3:0] i_g,
    input  wire [3:0] i_b,
    output wire [3:0] o_r,
    output wire [3:0] o_g,
    output wire [3:0] o_b
);

    // internal signal
    wire [11:0] gray;

    // gray scale conversion
    assign gray = 77 * i_r + 154 * i_g + 25 * i_b;

    // output assignment
    assign {o_r, o_g, o_b} = {gray[11:8], gray[11:8], gray[11:8]};

endmodule
