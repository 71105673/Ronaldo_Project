`timescale 1ns / 1ps

module Grid_Partition (
    input  logic       clk,
    input  logic       reset,
    input  logic       v_sync,
    input  logic       DE,
    input  logic       red_glove_detect,
    input  logic [9:0] x_pixel,
    output logic [2:0] selected_grid      // 0 = 없음, 1~5 = grid
);

    localparam SELECT_GRID_MIN = 500;

    logic [13:0] Grid[0:4];
    logic [2:0] grid_pos;
    logic [13:0] max01, max23, max0123;
    logic [2:0] grid_final;
    logic v_sync_delay;

    logic [13:0] max_val;

    // 현재 픽셀의 grid (0~4)
    assign grid_pos = (x_pixel / 128);

    // Grid 최대값 계산
    // assign max01 = (Grid[0] > Grid[1]) ? Grid[0] : Grid[1];
    // assign max23 = (Grid[2] > Grid[3]) ? Grid[2] : Grid[3];
    // assign max0123 = (max01 > max23) ? max01 : max23;

    assign selected_grid = grid_final;

    // v_sync delay
    always_ff @(posedge clk, posedge reset) begin
        if (reset) v_sync_delay <= 1'b0;
        else v_sync_delay <= v_sync;
    end

    // grid_final 계산 (rising edge에서)
    // always_ff @(posedge clk, posedge reset) begin
    //     if (reset) grid_final <= 3'd0;
    //     //else if (!v_sync && v_sync_delay) begin
    //     else if (!v_sync && v_sync_delay) begin
    //         if (max0123 == 0 && Grid[4] == 0) begin
    //             grid_final <= 3'd0;  // 장갑 없음
    //         end else begin
    //             grid_final <= (Grid[4] > max0123) ? 3'd5 :
    //                           (max0123 == Grid[0]) ? 3'd1 :
    //                           (max0123 == Grid[1]) ? 3'd2 :
    //                           (max0123 == Grid[2]) ? 3'd3 :
    //                           (max0123 == Grid[3]) ? 3'd4 : 3'd0;
    //         end
    //     end
    // end


    // grid_final 계산 (v_sync 하강 에지에서 안전하게)
    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            grid_final <= 3'd0;
        end else if (!v_sync && v_sync_delay) begin
            // 최대값 계산
            max_val = Grid[0];
            grid_final = 3'd1;  // 기본값: Grid 0

            if (Grid[1] > max_val) begin
                max_val = Grid[1];
                grid_final = 3'd2;
            end
            if (Grid[2] > max_val) begin
                max_val = Grid[2];
                grid_final = 3'd3;
            end
            if (Grid[3] > max_val) begin
                max_val = Grid[3];
                grid_final = 3'd4;
            end
            if (Grid[4] > max_val) begin
                max_val = Grid[4];
                grid_final = 3'd5;
            end

            // 모든 Grid가 0이면 장갑 없음
            if (max_val <= SELECT_GRID_MIN) grid_final = 3'd0;
        end
    end

    always_comb begin

    end

    /*
    always_ff @( posedge clk, posedge reset ) begin
        if (reset) begin
            Grid[0] <= 0;
            Grid[1] <= 0;
            Grid[2] <= 0;
            Grid[3] <= 0;
            Grid[4] <= 0;
        end        
        else begin
            Grid[0] <= 1;  
            Grid[1] <= 1;
            Grid[2] <= 1;
            Grid[3] <= 1;
            Grid[4] <= 1;
        end
    end
*/


    // Grid 누적
    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            Grid[0] <= 0;
            Grid[1] <= 0;
            Grid[2] <= 0;
            Grid[3] <= 0;
            Grid[4] <= 0;
        end else if (v_sync && !v_sync_delay) begin
            // 한 프레임 끝나면 초기화
            Grid[0] <= 0;
            Grid[1] <= 0;
            Grid[2] <= 0;
            Grid[3] <= 0;
            Grid[4] <= 0;
        end else if (DE && red_glove_detect) begin
            case (grid_pos)
                0: Grid[0] <= Grid[0] + 1;
                1: Grid[1] <= Grid[1] + 1;
                2: Grid[2] <= Grid[2] + 1;
                3: Grid[3] <= Grid[3] + 1;
                4: Grid[4] <= Grid[4] + 1;
            endcase
        end

    end


endmodule
