`timescale 1ns / 1ps

module OV7670_MemController (
    input  logic        clk, // Should be ov7670_pclk
    input  logic        reset,
    // ov7670 side (Asynchronous Inputs)
    input  logic        href,
    input  logic        vsync,
    input  logic [ 7:0] ov7670_data,
    // memory side
    output logic        we,
    output logic [16:0] wAddr,
    output logic [15:0] wData
);
    logic [15:0] pixel_data;
    logic [ 9:0] h_counter;
    logic [ 7:0] v_counter;

    // [수정 1] 외부 입력을 위한 2단 동기화기 (FF 처리)
    logic href_s1, href_s2;
    logic vsync_s1, vsync_s2;

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            {href_s1, href_s2}   <= 2'b0;
            {vsync_s1, vsync_s2} <= 2'b0;
        end else begin
            href_s1  <= href;
            href_s2  <= href_s1;
            vsync_s1 <= vsync;
            vsync_s2 <= vsync_s1;
        end
    end

    // 동기화된 신호의 에지(edge) 감지
    logic href_falling_edge;
    logic vsync_rising_edge;
    assign href_falling_edge = !href_s2 &&  href_s1;
    assign vsync_rising_edge =  vsync_s2 && !vsync_s1;

    assign wAddr = v_counter * 320 + h_counter[9:1] - 1;
    assign wData = pixel_data;

    // 수평 카운터 및 데이터 처리
    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            h_counter  <= 0;
            pixel_data <= 0;
            we         <= 1'b0;
        end else begin
            // 안정화된 href_s2 신호 사용
            if (href_s2) begin
                h_counter <= h_counter + 1;
                if (h_counter[0] == 1'b0) begin
                    pixel_data[15:8] <= ov7670_data;
                    we <= 1'b0;
                end else begin
                    pixel_data[7:0] <= ov7670_data;
                    we <= 1'b1;
                end
            end else begin
                h_counter <= 0;
                we        <= 1'b0;
            end
        end
    end

    // [수정 2] 안정적인 에지 감지 방식으로 v_counter 제어
    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            v_counter <= 0;
        end else begin
            if (vsync_rising_edge) begin // 프레임 시작 시 리셋
                v_counter <= 0;
            end
            else if (href_falling_edge) begin // 라인 종료 시 증가
                if (v_counter < 239) begin
                    v_counter <= v_counter + 1;
                end
            end
        end
    end
endmodule