`timescale 1ns / 1ps

module RedGlove_Detector (
    input  wire [3:0] r_data,
    input  wire [3:0] g_data,
    input  wire [3:0] b_data,
    output wire       detect
);

    // parameters
    localparam SATURATION = 3;
    localparam DIFFERENCE = 2;

    // internal signals
    wire [3:0] max_val, min_val, delta;

    // 최대값, 최소값 계산
    assign max_val = (r_data >= g_data && r_data >= b_data) ? r_data :
                     (g_data >= b_data) ? g_data : b_data;

    assign min_val = (r_data <= g_data && r_data <= b_data) ? r_data :
                     (g_data <= b_data) ? g_data : b_data;

    assign delta = max_val - min_val;

    // 빨강 검출 조건 (단순화)
    // R이 제일 크고, 빨강 성분이 충분히 크며, 채도(S)가 일정 이상일 때
    assign detect = (r_data == max_val) && (delta >= SATURATION) &&
                    ((r_data - g_data) >= DIFFERENCE) && ((r_data - b_data) >= DIFFERENCE);

endmodule
