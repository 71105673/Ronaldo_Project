`timescale 1ns / 1ps

module VGA_Decoder (
    input  wire       clk,
    input  wire       reset,
    output wire       pclk,
    output wire       h_sync,
    output wire       v_sync,
    output wire [9:0] x_pixel,
    output wire [9:0] y_pixel,
    output wire       DE
);

    wire [9:0] v_counter;
    wire [9:0] h_counter;

    Pixel_clk_gen U_P_CLK (
        .clk(clk),
        .reset(reset),
        .pclk(pclk)
    );

    pixel_counter U_P_COUNTER (
        .pclk(pclk),
        .reset(reset),
        .v_counter(v_counter),
        .h_counter(h_counter)
    );

    vga_decoder U_VGA_Decoder (
        .h_counter(h_counter),
        .v_counter(v_counter),
        .h_sync(h_sync),
        .v_sync(v_sync),
        .x_pixel(x_pixel),
        .y_pixel(y_pixel),
        .DE(DE)
    );

endmodule


module Pixel_clk_gen (
    input  wire clk,
    input  wire reset,
    output reg  pclk
);

    reg [1:0] p_counter;  // 25 MHz

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            p_counter <= 2'b00;
            pclk      <= 1'b0;
        end else begin
            if (p_counter == 2'b11) begin
                p_counter <= 2'b00;
                pclk      <= 1'b1;
            end else begin
                p_counter <= p_counter + 1'b1;
                pclk      <= 1'b0;
            end
        end
    end

endmodule


module pixel_counter (
    input  wire       pclk,
    input  wire       reset,
    output reg [9:0]  v_counter,
    output reg [9:0]  h_counter
);

    localparam H_MAX = 800;
    localparam V_MAX = 525;  // VGA Spec

    always @(negedge pclk or posedge reset) begin
        if (reset) begin
            h_counter <= 10'd0;
        end else begin
            if (h_counter == H_MAX - 1) begin
                h_counter <= 10'd0;
            end else begin
                h_counter <= h_counter + 1'b1;
            end
        end
    end

    always @(negedge pclk or posedge reset) begin
        if (reset) begin
            v_counter <= 10'd0;
        end else begin
            if (h_counter == H_MAX - 1) begin
                if (v_counter == V_MAX - 1) begin
                    v_counter <= 10'd0;
                end else begin
                    v_counter <= v_counter + 1'b1;
                end
            end
        end
    end

endmodule


module vga_decoder (
    input  wire [9:0] h_counter,
    input  wire [9:0] v_counter,
    output wire       h_sync,
    output wire       v_sync,
    output wire [9:0] x_pixel,
    output wire [9:0] y_pixel,
    output wire       DE
);

    localparam H_Visible_area = 640;
    localparam H_Front_porch  = 16;
    localparam H_Sync_pulse   = 96;
    localparam H_Back_porch   = 48;
    localparam H_Whole_line   = 800;

    localparam V_Visible_area = 480;
    localparam V_Front_porch  = 10;
    localparam V_Sync_pulse   = 2;
    localparam V_Back_porch   = 33;
    localparam V_Whole_frame  = 525;

    assign h_sync  = !((h_counter >= (H_Visible_area + H_Front_porch)) &&
                       (h_counter <  (H_Visible_area + H_Front_porch + H_Sync_pulse)));

    assign v_sync  = !((v_counter >= (V_Visible_area + V_Front_porch)) &&
                       (v_counter <  (V_Visible_area + V_Front_porch + V_Sync_pulse)));

    assign DE      = (h_counter < H_Visible_area) && (v_counter < V_Visible_area);
    assign x_pixel = h_counter;
    assign y_pixel = v_counter;

endmodule
