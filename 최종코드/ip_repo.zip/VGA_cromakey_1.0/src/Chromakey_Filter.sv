`timescale 1ns / 1ps

module Chromakey_Filter (
    input  logic       DE,
    input  logic [9:0] x,
    input  logic [9:0] y,
    input  logic [4:0] i_r,
    input  logic [5:0] i_g,
    input  logic [4:0] i_b,
    output logic       green,
    output logic [3:0] r_port,
    output logic [3:0] g_port,
    output logic [3:0] b_port
);

    logic [16:0] bg_addr;
    logic [15:0] bg_data;
    logic [7:0] cam_h, cam_s;
    logic [3:0] cam_v;

    ImgReader U_Chromakey_Reader (
        .DE    (DE),
        .x     (x),
        .y     (y),
        .addr  (bg_addr),
        .data  (bg_data),
        .r_port(r_port),
        .g_port(g_port),
        .b_port(b_port)
    );

    BackgroundROM U_BACKROM (
        .raddr(bg_addr),
        .data (bg_data)
    );

    GreenFilter_RGB U_ChromakeyFilter_RGB(
        .i_r(i_r),
        .i_g(i_g),
        .i_b(i_b),
        .green(green)
    );
endmodule

////////////////////////////////////////////////////////////

module BackgroundROM (
    input  logic [16:0] raddr,
    output logic [15:0] data
);
    logic [15:0] mem[0:320*240-1];

    initial begin
        $readmemh("background.mem", mem);  // QQVGA
    end

    assign data = mem[raddr];
endmodule

////////////////////////////////////////////////////////////

// module GreenFilter (
//     input  logic [7:0] i_h,
//     input  logic [7:0] i_s,
//     input  logic [3:0] i_v,
//     output logic green
// );
//     // Hue (색상) 범위: 녹색 계열
//     parameter H_MIN = 8'd85; 
//     parameter H_MAX = 8'd110; 

//     // Saturation (채도) 범위
//     parameter S_MIN = 8'd120;   // 너무 탁한 색 제외
//     parameter S_MAX = 8'd240;  // 과포화 반사광 제외

//     // Value (밝기) 최소값
//     parameter V_MIN = 4'd2;

//     always_comb begin
//         green = 1'b0; // 기본값
//         if (i_h >= H_MIN && i_h <= H_MAX) begin
//             if (i_s >= S_MIN && i_s <= S_MAX) begin
//                 if (i_v >= V_MIN) begin
//                     green = 1'b1;
//                 end
//             end
//         end
//     end
// endmodule

////////////////////////////////////////////////////////////

// module GreenFilter_RGB (
//     input  logic [4:0] i_r,
//     input  logic [5:0] i_g,
//     input  logic [4:0] i_b,
//     output logic       green
// );


    // // G가 R, B보다 최소한 이 값만큼은 커야 함 (녹색 우위 강도)
    // parameter DOMINANCE_OFFSET = 6'd8;

    // // G의 최소 밝기 (너무 어두운 녹색 제외)
    // parameter G_MIN_THRESH = 6'd1; // 6비트 G 기준 (0~63)
    // // ======================================================

    // logic [5:0] r_6bit, b_6bit;
    // logic g_is_dominant;
    // logic g_is_bright_enough;

    // // R과 B를 6비트로 확장하여 G와 비교
    // assign r_6bit = {i_r, i_r[4]};
    // assign b_6bit = {i_b, i_b[4]};

    // // 조건 1: G가 R과 B보다 월등히 높은가?
    // assign g_is_dominant = (i_g > r_6bit + DOMINANCE_OFFSET) && (i_g > b_6bit + DOMINANCE_OFFSET);
    
    // // 조건 2: G가 최소 밝기 이상인가?
    // assign g_is_bright_enough = (i_g > G_MIN_THRESH);

    // // 최종 판정: 두 조건을 모두 만족하면 green!
    // assign green = g_is_dominant && g_is_bright_enough;




//     // parameters
//     localparam SATURATION = 3;
//     localparam DIFFERENCE = 7;

//     wire [5:0] max_val, min_val, delta;
//     wire [5:0] g_data, r_data, b_data;

//     assign r_data = {1'b0,i_r};
//     assign g_data = i_g;
//     assign b_data = {1'b0,i_b};

//     assign max_val = (g_data >= r_data && g_data >= b_data) ? g_data :
//                      (r_data >= b_data) ? r_data : b_data;

//     assign min_val = (g_data <= r_data && g_data <= b_data) ? g_data :
//                      (r_data <= b_data) ? r_data : b_data;

//     assign delta = max_val - min_val;

//     assign green = (g_data == max_val) && (delta >= SATURATION) &&
//                     ((g_data - r_data) >= DIFFERENCE) && ((g_data - b_data) >= DIFFERENCE);

// endmodule


// module GreenFilter_RGB ( //유경
//     input  logic [4:0] i_r,
//     input  logic [5:0] i_g,
//     input  logic [4:0] i_b,
//     output logic       green
// );
    
//     // G 최소 밝기
//     parameter G_MIN_THRESH = 6'd7; 

//     // R, B 최대값
//     // 어두운 녹색은 R,B 값이 매우 낮아야 함 -> 사람이 투명해지면 값 더 낮추기 앙앙
//     parameter R_MAX_THRESH = 5'd30; 
//     parameter B_MAX_THRESH = 5'd30;

//     // G 우위도: 이 값은 낮춰서 어두운 녹색을 잘 인식하게 해야 함 -> 배경에 지글거림 남으면 이 값 낮추기 
//     parameter DOMINANCE_OFFSET = 6'd1;

//     logic [5:0] r_6bit, b_6bit;
//     logic g_is_dominant, g_is_bright_enough, is_pure_green;

//     assign r_6bit = {i_r, i_r[4]};
//     assign b_6bit = {i_b, i_b[4]};

//     // G가 최소 밝기 이상인가
//     assign g_is_bright_enough = (i_g >= G_MIN_THRESH);
    
//     // R과 B 성분이 절대적으로 낮은가 -> 이게 핵심
//     assign is_pure_green      = (i_r < R_MAX_THRESH) && (i_b < B_MAX_THRESH);

//     // G가 R과 B보다 충분히 높은가
//     assign g_is_dominant      = (i_g > r_6bit + DOMINANCE_OFFSET) && (i_g > b_6bit + DOMINANCE_OFFSET);
    
//     assign green = g_is_bright_enough && is_pure_green && g_is_dominant;
// endmodule

// module GreenFilter_RGB (
//     input  logic [4:0] i_r,
//     input  logic [5:0] i_g,
//     input  logic [4:0] i_b,
//     output logic       green
// );

//     // --- '밝은 녹색' 판단 기준 (완화) ---
//     parameter BRIGHT_G_THRESH         = 6'd16; 
//     parameter DOMINANCE_OFFSET_BRIGHT = 6'd3;   // 더 쉽게 G 우위 인정
//     parameter R_MAX_BRIGHT            = 5'd15;  // R 허용치 완화
//     parameter B_MAX_BRIGHT            = 5'd15;  // B 허용치 완화

//     // --- '어두운 녹색' 판단 기준 (완화) ---
//     parameter DARK_G_THRESH     = 6'd14;
//     parameter R_MAX_THRESH_DARK = 5'd6;  // 허용치 
//     parameter B_MAX_THRESH_DARK = 5'd7;  // 허용치 
//     // ======================================================

//     logic [5:0] r_6bit, b_6bit;
//     logic is_bright_green, is_dark_pure_green;

//     assign r_6bit = {i_r, i_r[4]};
//     assign b_6bit = {i_b, i_b[4]};

//     // 조건 1: 밝은 녹색
//     assign is_bright_green = (i_g >= BRIGHT_G_THRESH) &&
//                              (i_g > r_6bit + DOMINANCE_OFFSET_BRIGHT) &&
//                              (i_g > b_6bit + DOMINANCE_OFFSET_BRIGHT) &&
//                              (i_r < R_MAX_BRIGHT) &&
//                              (i_b < B_MAX_BRIGHT);

//     // 조건 2: 어두운 녹색
//     assign is_dark_pure_green = (i_g >= DARK_G_THRESH) && (i_g < BRIGHT_G_THRESH) &&
//                                 (i_r < R_MAX_THRESH_DARK) &&
//                                 (i_b < B_MAX_THRESH_DARK);

//     assign green = is_bright_green || is_dark_pure_green;
// endmodule

module GreenFilter_RGB (
    input  logic [4:0] i_r,
    input  logic [5:0] i_g,
    input  logic [4:0] i_b,
    output logic       green
);

    // --- 흰색 옷 입은 사람이 들어오면 되는 코드 ---
    // parameter G_THRESH         = 6'd7;  // G 최소값
    // parameter DOMINANCE_OFFSET_R = 6'd1;   // G가 R/B보다 얼마나 커야 하는지
    // parameter DOMINANCE_OFFSET_B = 6'd3;   // G가 R/B보다 얼마나 커야 하는지
    // parameter R_MAX            = 5'd12;  // R 최대값
    // parameter B_MAX            = 5'd15;  // B 최대값

    // --- 흰색 검정색 둘 다 뚫리긴 하는데 그린 배경은 잘 나옴 ---
    // parameter G_THRESH           = 6'd9; // 최소한 초록색으로 인식할 G값
    // parameter DOMINANCE_OFFSET_R = 6'd5;  // G가 R보다 최소 몇만큼 커야하는지
    // parameter DOMINANCE_OFFSET_B = 6'd4;  // G가 B보다 최소 몇만큼 커야하는지
    // parameter R_MAX              = 5'd28; // 허용 가능한 R 최대값
    // parameter B_MAX              = 5'd28; // 허용 가능한 B 최대값

    // 3. --- 검정색 빼고는 상당히 잘 되는 버젼!!! --- 
    // parameter G_THRESH           = 6'd12; // 최소 초록 인식
    // parameter DOMINANCE_OFFSET_R = 6'd6;  // R보다 최소 6 커야 OK
    // parameter DOMINANCE_OFFSET_B = 6'd6;  // B보다 최소 6 커야 OK
    // parameter R_MAX              = 5'd20; // R 최대 허용치 낮춤
    // parameter B_MAX              = 5'd20; // B 최대 허용치 낮춤

    // 4. 이거는 저 위에꺼보다 초록이 덜 잡히는것 같은 버젼
    // parameter G_THRESH           = 6'd14; // 최소 초록 인식 ↑
    // parameter DOMINANCE_OFFSET_R = 6'd6;  // 그대로
    // parameter DOMINANCE_OFFSET_B = 6'd6;  // 그대로
    // parameter R_MAX              = 5'd18; // R 최대 허용치 ↓
    // parameter B_MAX              = 5'd18; // B 최대 허용치 ↓

    // 5. 이거는 3에 비해 더 검정이 잘 잡히는 것 같은 Version
    // parameter G_THRESH           = 6'd13; // 최소 초록 인식 ↑
    // parameter DOMINANCE_OFFSET_R = 6'd5;  // 그대로
    // parameter DOMINANCE_OFFSET_B = 6'd6;  // 그대로
    // parameter R_MAX              = 5'd18; // R 최대 허용치 ↓
    // parameter B_MAX              = 5'd20; // B 최대 허용치 ↓

    // 6. 이것도 크게 의미는 없어보임
    // parameter G_THRESH           = 6'd14; // 최소 초록 인식 유지
    // parameter DOMINANCE_OFFSET_R = 6'd4;  // R 대비 G 우위 완화 (초록 인식 안정)
    // parameter DOMINANCE_OFFSET_B = 6'd5;  // B 대비 G 우위 완화
    // parameter R_MAX              = 5'd20; // R 최대 허용치 약간 완화
    // parameter B_MAX              = 5'd20; // B 최대 허용치 약간 완화

    // 7. 4,5,6이랑 별개로 뭐 비슷한 수준인 것 같음 그리고 초록이 그나마 덜 잡히는 느낌이 듬.
    // parameter G_THRESH           = 6'd14; // 최소 초록 인식
    // parameter DOMINANCE_OFFSET_R = 6'd6;  // R 대비 G 우위 강화 → 검정 제외
    // parameter DOMINANCE_OFFSET_B = 6'd6;  // B 대비 G 우위 강화 → 검정 제외
    // parameter R_MAX              = 5'd22; // 초록 일부 누락 방지
    // parameter B_MAX              = 5'd22; // 초록 일부 누락 방지

    // 8. 이거 엄청 나름 잘 되는 것 같은 느낌이 들어 이게 지금까지 최고 버젼임
    // parameter G_THRESH           = 6'd25; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd4;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd5;  // B 대비 G 우위
    // parameter R_MAX              = 5'd22; // R 최대 허용치
    // parameter B_MAX              = 5'd22; // B 최대 허용치

    // 9. 이게 최최최고 이건 검정은 조금 뚫리고 흰색도 됨 
    // parameter G_THRESH           = 6'd30; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd4;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd5;  // B 대비 G 우위
    // parameter R_MAX              = 5'd22; // R 최대 허용치
    // parameter B_MAX              = 5'd22; // B 최대 허용치

    // 10. 이거 검정은 되는데 흰색이 안됨
    // parameter G_THRESH           = 6'd36; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd4;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd5;  // B 대비 G 우위
    // parameter R_MAX              = 5'd22; // R 최대 허용치
    // parameter B_MAX              = 5'd22; // B 최대 허용치

    // 11. 10보다는 나음
    // parameter G_THRESH           = 6'd33; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd4;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd5;  // B 대비 G 우위
    // parameter R_MAX              = 5'd22; // R 최대 허용치
    // parameter B_MAX              = 5'd22; // B 최대 허용치


    // 12. 테스트
    //parameter G_THRESH           = 6'd32; // 최소 초록 인식 (검정 제외)
    //parameter DOMINANCE_OFFSET_R = 6'd4;  // R 대비 G 우위
    //parameter DOMINANCE_OFFSET_B = 6'd5;  // B 대비 G 우위
    //parameter R_MAX              = 5'd22; // R 최대 허용치
    //parameter B_MAX              = 5'd22; // B 최대 허용치

    // 13. test // 12랑 비슷
    // parameter G_THRESH           = 6'd31; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd4;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd5;  // B 대비 G 우위
    // parameter R_MAX              = 5'd22; // R 최대 허용치
    // parameter B_MAX              = 5'd22; // B 최대 허용치

    //14 조금 나아짐
    // parameter G_THRESH           = 6'd31; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd7;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd7;  // B 대비 G 우위
    // parameter R_MAX              = 5'd30; // R 최대 허용치
    // parameter B_MAX              = 5'd30; // B 최대 허용치

    //15 몸도 뚫림
    // parameter G_THRESH           = 6'd31; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd4;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd4;  // B 대비 G 우위
    // parameter R_MAX              = 5'd30; // R 최대 허용치
    // parameter B_MAX              = 5'd30; // B 최대 허용치
    
    //16 tlqkf
    // parameter G_THRESH           = 6'd28; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd7;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd7;  // B 대비 G 우위
    // parameter R_MAX              = 5'd30; // R 최대 허용치
    // parameter B_MAX              = 5'd30; // B 최대 허용치

    //17 꽤괜인데 초록 어두운 부분 잘 못잡음
    // parameter G_THRESH           = 6'd24; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd7;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd7;  // B 대비 G 우위
    // parameter R_MAX              = 5'd25; // R 최대 허용치
    // parameter B_MAX              = 5'd25; // B 최대 허용치
    
    //18 17과 비슷
    // parameter G_THRESH           = 6'd22; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd7;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd7;  // B 대비 G 우위
    // parameter R_MAX              = 5'd25; // R 최대 허용치
    // parameter B_MAX              = 5'd25; // B 최대 허용치
    
    //19 괜춘 그림자 지는 거 줄어듦
    // parameter G_THRESH           = 6'd20; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd7;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd7;  // B 대비 G 우위
    // parameter R_MAX              = 5'd25; // R 최대 허용치
    // parameter B_MAX              = 5'd25; // B 최대 허용치

    //20 노이즈 으으
    // parameter G_THRESH           = 6'd18; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd7;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd7;  // B 대비 G 우위
    // parameter R_MAX              = 5'd28; // R 최대 허용치
    // parameter B_MAX              = 5'd28; // B 최대 허용치
    
    //21 뭐임 개거지같음
    // parameter G_THRESH           = 6'd18; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd7;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd7;  // B 대비 G 우위
    // parameter R_MAX              = 5'd25; // R 최대 허용치
    // parameter B_MAX              = 5'd25; // B 최대 허용치

    //22 별로
    // parameter G_THRESH           = 6'd20; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd8;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd8;  // B 대비 G 우위
    // parameter R_MAX              = 5'd25; // R 최대 허용치
    // parameter B_MAX              = 5'd25; // B 최대 허용치

    //23 지랄
    // parameter G_THRESH           = 6'd26; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd10;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd10;  // B 대비 G 우위
    // parameter R_MAX              = 5'd24; // R 최대 허용치
    // parameter B_MAX              = 5'd24; // B 최대 허용치

    //24 검정 뚫림 -> G_THRESH를 너무 낮추면 안 될 거 같음
    // parameter G_THRESH           = 6'd15; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd7;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd7;  // B 대비 G 우위
    // parameter R_MAX              = 5'd25; // R 최대 허용치
    // parameter B_MAX              = 5'd25; // B 최대 허용치

    //25 검정 안 뚫림 -> 노이즈만 잡으면 될 거 같음
    // parameter G_THRESH           = 6'd16; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd7;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd7;  // B 대비 G 우위
    // parameter R_MAX              = 5'd25; // R 최대 허용치
    // parameter B_MAX              = 5'd25; // B 최대 허용치

    //26 노이즈 우우
    // parameter G_THRESH           = 6'd15; // 최소 초록 인식 (검정 제외)
    // parameter DOMINANCE_OFFSET_R = 6'd8;  // R 대비 G 우위
    // parameter DOMINANCE_OFFSET_B = 6'd8;  // B 대비 G 우위
    // parameter R_MAX              = 5'd24; // R 최대 허용치
    // parameter B_MAX              = 5'd24; // B 최대 허용치

    //27
    parameter G_THRESH           = 6'd19; // 최소 초록 인식 (검정 제외)
    parameter DOMINANCE_OFFSET_R = 6'd7;  // R 대비 G 우위
    parameter DOMINANCE_OFFSET_B = 6'd7;  // B 대비 G 우위
    parameter R_MAX              = 5'd25; // R 최대 허용치
    parameter B_MAX              = 5'd25; // B 최대 허용치

    logic [5:0] r_6bit, b_6bit;

    // R/B를 6비트로 확장
    assign r_6bit = {i_r, i_r[4]};
    assign b_6bit = {i_b, i_b[4]};

    // 녹색 판정
    assign green = (i_g >= G_THRESH) &&
                   (i_g > r_6bit + DOMINANCE_OFFSET_R) &&
                   (i_g > b_6bit + DOMINANCE_OFFSET_B) &&
                   (i_r < R_MAX) &&
                   (i_b < B_MAX);



endmodule


////////////////////////////////////////////////////////////

module ImgReader (
    input  logic        DE,
    input  logic [ 9:0] x,
    input  logic [ 9:0] y,
    output logic [16:0] addr,
    input  logic [15:0] data,
    output logic [ 3:0] r_port,
    output logic [ 3:0] g_port,
    output logic [ 3:0] b_port
);
    logic img_show;

    assign img_show = (DE && (x < 640) && (y < 480));
    assign addr = img_show ? ((y >> 1) * 320 + (x >> 1)) : 17'bz;
    assign {r_port, g_port, b_port} = img_show ? {data[15:12], data[10:7], data[4:1]} : 12'b0;
endmodule

////////////////////////////////////////////////////////////