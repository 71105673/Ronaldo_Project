`timescale 1ns/1ps

// VGA_MemController의 4b RGB + den을 받아
// 살색이면 흰색(1111), 아니면 검정(0000)으로 내보내는 간단판
module flesh_color (
    input  logic       den,     // 유효 픽셀(예: vga_den 또는 de_raw)
    input  logic [3:0] r_in,
    input  logic [3:0] g_in,
    input  logic [3:0] b_in,

    output logic [3:0] r_out,
    output logic [3:0] g_out,
    output logic [3:0] b_out
);
    // ---- 4->8비트 확장 ----
    wire [7:0] R8 = {r_in, r_in};
    wire [7:0] G8 = {g_in, g_in};
    wire [7:0] B8 = {b_in, b_in};

    // ---- YCbCr 근사 (BT.601 정수화, 조합만 사용) ----
    // Cb = 128 + (-43R -85G +128B)/256
    // Cr = 128 + ( 128R -107G -21B)/256
    wire signed [17:0] cb_acc = -18'sd43 * $signed({1'b0,R8})
                              + -18'sd85 * $signed({1'b0,G8})
                              +  18'sd128* $signed({1'b0,B8});
    wire signed [17:0] cr_acc =  18'sd128* $signed({1'b0,R8})
                              + -18'sd107* $signed({1'b0,G8})
                              + -18'sd21 * $signed({1'b0,B8});
    wire [7:0] Cb = 8'd128 + (cb_acc >>> 8);  // 간단화: 포화 생략
    wire [7:0] Cr = 8'd128 + (cr_acc >>> 8);

    // ---- 피부색 판정 (현장에 맞게 튜닝 권장) ----
    // 기본: 77 ≤ Cb ≤ 127, 133 ≤ Cr ≤ 173
    localparam [7:0] CB_MIN = 8'd77,  CB_MAX = 8'd127;
    localparam [7:0] CR_MIN = 8'd133, CR_MAX = 8'd173;
    wire is_skin = den
                && (Cb >= CB_MIN) && (Cb <= CB_MAX)
                && (Cr >= CR_MIN) && (Cr <= CR_MAX)
                // 간단 RGB 보조 규칙(오탑 감소, 원치 않으면 지워도 됨)
                && (r_in > g_in) && (r_in > b_in);

    // ---- 출력: 살색=흰, 나머지=검 ----
    // 조합 할당으로 간단하게
    assign {r_out, g_out, b_out} = is_skin ? 12'hFFF : 12'h000;

endmodule
