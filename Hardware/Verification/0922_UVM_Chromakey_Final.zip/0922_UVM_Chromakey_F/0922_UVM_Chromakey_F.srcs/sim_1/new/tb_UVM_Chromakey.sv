`timescale 1ns / 1ps

// 1. DUT와 Testbench를 연결하는 Interface (RGB565로 수정)
interface chromakey_intf (
    input bit clk
);
    logic        DE;
    logic [9:0]  x, y;
    logic [4:0]  i_r; // DUT 입력에 맞게 5-bit
    logic [5:0]  i_g; // DUT 입력에 맞게 6-bit
    logic [4:0]  i_b; // DUT 입력에 맞게 5-bit
    logic        green_out; // DUT의 green 출력만 모니터링
endinterface

///////////////////////////////////////////////////////////////////////////

// 2. Transaction 클래스 (green 신호만 검증하도록 단순화)
class PixelTransaction;
    logic             de;
    rand logic [9:0]  x, y;
    rand logic [4:0]  r;
    rand logic [5:0]  g;
    rand logic [4:0]  b;

    logic        green_out; // Monitor가 수집할 green 신호

    constraint c_valid_vga_coords { x < 640; y < 480; }

    function new(); 
        this.de = 1'b1; 
    endfunction

    task print(string name);
        $display("[%s] DE=%b, (%0d, %0d), RGB_in=(%h,%h,%h) -> Green=%b",
                 name, de, x, y, r, g, b, green_out);
    endtask
endclass

///////////////////////////////////////////////////////////////////////////
// 3. Generator
class generator;
    PixelTransaction tr;
    mailbox #(PixelTransaction) gen2drv_mbox;
    event scb2gen_event;

    function new(mailbox#(PixelTransaction) gen2drv_mbox, event scb2gen_event);
        this.gen2drv_mbox = gen2drv_mbox;
        this.scb2gen_event = scb2gen_event;
    endfunction

    task run(int loop);
        repeat (loop) begin
            tr = new();
            if (!tr.randomize()) $error("Randomization Failed!");
            tr.print("GEN");
            gen2drv_mbox.put(tr);
            @(scb2gen_event);
        end
    endtask
endclass
///////////////////////////////////////////////////////////////////////////
// 4. Driver
class driver;
    PixelTransaction tr;
    mailbox #(PixelTransaction) gen2drv_mbox;
    virtual chromakey_intf ck_if;

    function new(mailbox #(PixelTransaction) gen2drv_mbox, virtual chromakey_intf ck_if);
        this.gen2drv_mbox = gen2drv_mbox;
        this.ck_if = ck_if;
    endfunction

    task run();
        forever begin
            gen2drv_mbox.get(tr);
            @(posedge ck_if.clk);
            ck_if.DE  <= tr.de;
            ck_if.x   <= tr.x;
            ck_if.y   <= tr.y;
            ck_if.i_r <= tr.r;
            ck_if.i_g <= tr.g;
            ck_if.i_b <= tr.b;
            tr.print("DRV");
        end
    endtask
endclass
///////////////////////////////////////////////////////////////////////////
// 5. Monitor (변경 없음)
class monitor;
    PixelTransaction tr;
    mailbox #(PixelTransaction) mon2scb_mbox;
    virtual chromakey_intf ck_if;
    function new(mailbox #(PixelTransaction) mon2scb_mbox, virtual chromakey_intf ck_if);
        this.mon2scb_mbox = mon2scb_mbox;
        this.ck_if = ck_if;
    endfunction
    task run();
        forever begin
            @(posedge ck_if.clk);
            #1;
            tr = new();
            tr.de = ck_if.DE;
            tr.x  = ck_if.x;
            tr.y  = ck_if.y;
            tr.r  = ck_if.i_r;
            tr.g  = ck_if.i_g;
            tr.b  = ck_if.i_b;
            tr.green_out = ck_if.green_out; // green 신호만 샘플링
            tr.print("MON");
            mon2scb_mbox.put(tr);
        end
    endtask
endclass
///////////////////////////////////////////////////////////////////////////

// 6. Scoreboard (★★ Reference Model 완성 ★★)
class Scoreboard;
    PixelTransaction tr;
    mailbox #(PixelTransaction) mon2scb_mbox;
    event scb2gen_event;
    int total_cnt, pass_cnt, fail_cnt;

    function new(mailbox#(PixelTransaction) mon2scb_mbox, event scb2gen_event);
        this.mon2scb_mbox = mon2scb_mbox;
        this.scb2gen_event = scb2gen_event;
        this.total_cnt = 0; this.pass_cnt = 0; this.fail_cnt = 0;
        // 배경 ROM 로드 로직 제거
    endfunction

    // DUT의 GreenFilter_RGB 로직과 정확히 동일한 레퍼런스 모델
    function bit predict_green(logic [4:0] r, logic [5:0] g, logic [4:0] b);
        localparam G_THRESH = 6'd18;
        localparam DOMINANCE_OFFSET_R = 6'd7;
        localparam DOMINANCE_OFFSET_B = 6'd7;
        localparam R_MAX = 5'd28;
        localparam B_MAX = 5'd28;

        logic [5:0] r_6bit = {r, r[4]};
        logic [5:0] b_6bit = {b, b[4]};
        
        return (g >= G_THRESH) && (g > r_6bit + DOMINANCE_OFFSET_R) && (g > b_6bit + DOMINANCE_OFFSET_B) && (r < R_MAX) && (b < B_MAX);
    endfunction

    task run();
        forever begin
            mon2scb_mbox.get(tr);
            total_cnt++;
            tr.print("SCB");

            if (tr.de) begin
                logic ref_green;
                ref_green = predict_green(tr.r, tr.g, tr.b); // 예상 green 신호 계산

                // --- 비교 ---
                if (ref_green === tr.green_out) begin
                    pass_cnt++;
                    $display("PASS! Matched Green Signal!");
                end else begin
                    fail_cnt++;
                    $display("FAIL! Mismatched Green Signal!");
                    $display("  Input   : RGB=(%h,%h,%h)", tr.r, tr.g, tr.b);
                    $display("  Expected: Green=%b", ref_green);
                    $display("  Actual  : Green=%b", tr.green_out);
                end
            end
            ->scb2gen_event;
        end
    endtask
endclass

///////////////////////////////////////////////////////////////////////////
// 7. Environment (변경 없음)
class environment;
    mailbox #(PixelTransaction) gen2drv_mbox;
    mailbox #(PixelTransaction) mon2scb_mbox;

    generator  gen;
    driver     drv;
    monitor    mon;
    Scoreboard scb; // [수정] 대문자 'S'로 시작하는 Scoreboard 타입 사용

    event scb2gen_event;

    function new(virtual chromakey_intf ck_if);
        gen2drv_mbox = new();
        mon2scb_mbox = new();
        
        gen = new(gen2drv_mbox, scb2gen_event);
        drv = new(gen2drv_mbox, ck_if);
        mon = new(mon2scb_mbox, ck_if);
        scb = new(mon2scb_mbox, scb2gen_event);
    endfunction

    task run(int loop);
        fork
            gen.run(loop);
            drv.run();
            mon.run();
            scb.run();
        join_any;

        $display("-----------------------------------------");
        $display("           Simulation Result           ");
        $display("-----------------------------------------");
        $display("Total : %0d", scb.total_cnt);
        $display("Pass  : %0d", scb.pass_cnt);
        $display("Fail  : %0d", scb.fail_cnt);
        $display("-----------------------------------------");
        #50;
    endtask
endclass
///////////////////////////////////////////////////////////////////////////

// 8. 최상위 테스트벤치 모듈
module tb_top ();
    bit clk;
    chromakey_intf ck_if (clk);
    environment    env;

    // DUT의 사용하지 않는 출력 포트를 연결하기 위한 로컬 와이어
    logic [3:0] dut_r_port, dut_g_port, dut_b_port;

    // DUT Instantiation
    Chromakey_Filter DUT (
        .DE(ck_if.DE),
        .x(ck_if.x),
        .y(ck_if.y),
        .i_r(ck_if.i_r),
        .i_g(ck_if.i_g),
        .i_b(ck_if.i_b),
        .green(ck_if.green_out),
        // 사용하지 않는 출력 포트는 테스트벤치의 로컬 와이어에 연결
        .r_port(dut_r_port),
        .g_port(dut_g_port),
        .b_port(dut_b_port)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 1;
        env = new(ck_if);
        env.run(10000);
        $finish;
    end
endmodule