`timescale 1ns / 1ps

module VGA_Camera_Display (
    input  logic       clk,
    input  logic       reset,
    input  logic [1:0] sw_mode,
    input  logic       sw_gray,
    input  logic [4:0] btn_in,
    // ov7670 side
    output logic       ov7670_xclk,
    input  logic       ov7670_pclk,
    input  logic       ov7670_href,
    input  logic       ov7670_vsync,
    input  logic [7:0] ov7670_data,

    // external port
    output logic       h_sync,
    output logic       v_sync,
    output logic [3:0] r_port,
    output logic [3:0] g_port,
    output logic [3:0] b_port,

    input  logic rx,
    output logic tx
);

    logic        ov7670_we;
    logic [16:0] ov7670_wAddr;
    logic [15:0] ov7670_wData;

    logic        vga_pclk;
    logic [ 9:0] vga_x_pixel;
    logic [ 9:0] vga_y_pixel;
    logic        vga_DE;

    logic        vga_den;
    logic [16:0] vga_rAddr;
    logic [15:0] vga_rData;

    logic [ 3:0] vga_r;
    logic [ 3:0] vga_g;
    logic [ 3:0] vga_b;

    logic [ 3:0] gray_r;
    logic [ 3:0] gray_g;
    logic [ 3:0] gray_b;

    logic [ 3:0] face_detected_r;
    logic [ 3:0] face_detected_g;
    logic [ 3:0] face_detected_b;
    logic [19:0] cen_data;

    logic [ 2:0] selected_grid;
    logic [3:0] grid_r, grid_g, grid_b;

    logic [ 2:0] selected_kick; 

    assign ov7670_xclk = vga_pclk;


    assign led = selected_grid;


    VGA_Decoder U_VGA_Decoder (
        .clk    (clk),
        .reset  (reset),
        .pclk   (vga_pclk),
        .h_sync (h_sync),
        .v_sync (v_sync),
        .x_pixel(vga_x_pixel),
        .y_pixel(vga_y_pixel),
        .DE     (vga_DE)
    );

    OV7670_MemController U_OV7670_MemController (
        .clk        (ov7670_pclk),
        .reset      (reset),
        .href       (ov7670_href),
        .vsync      (ov7670_vsync),
        .ov7670_data(ov7670_data),
        .we         (ov7670_we),
        .wAddr      (ov7670_wAddr),
        .wData      (ov7670_wData)
    );

    frame_buffer U_FrameBuffer (
        .wclk (ov7670_pclk),
        .we   (ov7670_we),
        .wAddr(ov7670_wAddr),
        .wData(ov7670_wData),
        .rclk (vga_pclk),
        .oe   (vga_den),
        .rAddr(vga_rAddr),
        .rData(vga_rData)
    );

    VGA_MemController U_VGAMemController (
        .DE     (vga_DE),
        .x_pixel(vga_x_pixel),
        .y_pixel(vga_y_pixel),
        .den    (vga_den),
        .rAddr  (vga_rAddr),
        .rData  (vga_rData),
        .r_port (vga_r),
        .g_port (vga_g),
        .b_port (vga_b)
    );

    GrayScaleFilter U_GRAY (
        .i_r(vga_r),
        .i_g(vga_g),
        .i_b(vga_b),
        .o_r(gray_r),
        .o_g(gray_g),
        .o_b(gray_b)
    );

    Red_Glove_Grid_Selector U_Red_Glove_Grid_Selector (
        .pclk         (vga_pclk),
        .reset        (reset),
        .r_in         (vga_r),
        .g_in         (vga_g),
        .b_in         (vga_b),
        .v_sync       (v_sync),
        .DE           (vga_den),
        .x_pixel      (vga_x_pixel),
        .selected_grid(selected_grid),
        .r_out        (grid_r),
        .g_out        (grid_g),
        .b_out        (grid_b)
    );

    Face_Detector U_Face_Detector (
        .pclk(vga_pclk),
        .reset(reset),
        .DE(vga_den),
        .r_in(vga_r),
        .g_in(vga_g),
        .b_in(vga_b),
        .x_pixel(vga_x_pixel),
        .y_pixel(vga_y_pixel),
        .sw_gray(sw_gray),
        .r_port(face_detected_r),
        .g_port(face_detected_g),
        .b_port(face_detected_b),
        .cen_data(cen_data)
    );

    btn_detector U_BTN_Detector (
        .clk            (clk),
        .reset          (reset),
        .btn_in         (btn_in),
        .selected_kick  (selected_kick)
    );

    mux_4x1 U_MUX (
        .sel         (sw_mode),
        .vga_rgb     ({vga_r, vga_g, vga_b}),
        .gray_rgb    ({gray_r, gray_g, gray_b}),
        .redglove_rgb({grid_r, grid_g, grid_b}),
        .face_detected_rgb({face_detected_r, face_detected_g, face_detected_b}),
        .rgb         ({r_port, g_port, b_port})
    );

    uart_intf U_UART (
        .clk(clk),
        .reset(reset),
        .grid_data(selected_grid),
        .kick_data(selected_kick),
        .face_data(cen_data),
        .rx(rx),
        .tx(tx)
    );

endmodule

module mux_4x1 (
    input  logic [ 1:0] sel,
    input  logic [11:0] vga_rgb,
    input  logic [11:0] gray_rgb,
    input  logic [11:0] redglove_rgb,
    input  logic [11:0] face_detected_rgb,
    output logic [11:0] rgb
);

    always_comb begin
        rgb = vga_rgb;
        case (sel)
            2'b00: rgb = vga_rgb;
            2'b01: rgb = gray_rgb;
            2'b10: rgb = redglove_rgb;
            2'b11: rgb = face_detected_rgb;
        endcase
    end

endmodule
