`timescale 1ns / 1ps

module select_grid (
    input  wire       DE,
    input  wire [2:0] selected_grid,  // 0 = 없음, 1~5 = Grid
    input  wire [9:0] x_pixel,
    input  wire [3:0] r_in,
    input  wire [3:0] g_in,
    input  wire [3:0] b_in,
    output reg  [3:0] r_out,
    output reg  [3:0] g_out,
    output reg  [3:0] b_out
);

    // 기본 출력은 입력 그대로
    always_comb begin
        r_out = r_in;
        g_out = g_in;
        b_out = b_in;

        if (DE && selected_grid != 0) begin
            // selected_grid에 맞춰 노란색 강조
            case (selected_grid)
                3'd1:
                    if (x_pixel < 128)
                        {r_out, g_out, b_out} = {4'd15, 4'd15, 4'd0};
                3'd2:
                    if (x_pixel >= 128 && x_pixel < 256)
                        {r_out, g_out, b_out} = {4'd15, 4'd15, 4'd0};
                3'd3:
                    if (x_pixel >= 256 && x_pixel < 384)
                        {r_out, g_out, b_out} = {4'd15, 4'd15, 4'd0};
                3'd4:
                    if (x_pixel >= 384 && x_pixel < 512)
                        {r_out, g_out, b_out} = {4'd15, 4'd15, 4'd0};
                3'd5:
                    if (x_pixel >= 512 && x_pixel < 640)
                        {r_out, g_out, b_out} = {4'd15, 4'd15, 4'd0};
                default: ;
            endcase
        end
    end

endmodule
