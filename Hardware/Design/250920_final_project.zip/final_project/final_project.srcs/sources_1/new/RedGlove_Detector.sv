`timescale 1ns / 1ps
/*
module RedGlove_Detector (
    input  logic [3:0] r_data,
    input  logic [3:0] g_data,
    input  logic [3:0] b_data,
    output logic       detect
);

    assign detect = (r_data > 4'b1100 && g_data < 4'b0111 && b_data < 4'b0111) ? 1 : 0;

endmodule
*/

/*
module RedGlove_Detector (
    input  logic [3:0] r_data,
    input  logic [3:0] g_data,
    input  logic [3:0] b_data,
    output logic       detect
);

    logic [4:0] r_minus_g;
    logic [4:0] r_minus_b;

    always_comb begin
        // R이 G, B보다 충분히 크도록 비교 (상대 차이)
        r_minus_g = r_data - g_data;
        r_minus_b = r_data - b_data;

        if (r_data > 4'd3 &&  // 최소 밝기 (너무 어두운 픽셀 제외)
            r_minus_g > 4'd2 &&  // R > G + 2
            r_minus_b > 4'd2)  // R > B + 2
            detect = 1;
        else detect = 0;
    end

endmodule
*/


module RedGlove_Detector (
    input  logic [3:0] r_data,
    input  logic [3:0] g_data,
    input  logic [3:0] b_data,
    output logic       detect
);

    localparam SATURATION = 3;
    localparam DIFFERENCE = 2;

    logic [3:0] max_val, min_val, delta;

    // 최대값, 최소값 계산
    assign max_val = (r_data >= g_data && r_data >= b_data) ? r_data :
                     (g_data >= b_data) ? g_data : b_data;

    assign min_val = (r_data <= g_data && r_data <= b_data) ? r_data :
                     (g_data <= b_data) ? g_data : b_data;

    assign delta = max_val - min_val;

    // 빨강 검출 조건 (단순화)
    // R이 제일 크고, 빨강 성분이 충분히 크며, 채도(S)가 일정 이상일 때
    assign detect = (r_data == max_val) && (delta >= SATURATION) &&  // 채도 조건
        ((r_data - g_data) >= DIFFERENCE) && ((r_data - b_data) >= DIFFERENCE);

endmodule
