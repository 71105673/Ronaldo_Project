`timescale 1ns / 1ps

module VGA_Decoder (
    input  logic       clk,
    output logic       pclk,
    input  logic       reset,
    output logic       h_sync,
    output logic       v_sync,
    output logic [9:0] x_pixel,
    output logic [9:0] y_pixel,
    output logic       DE
);
    logic [9:0] v_counter;
    logic [9:0] h_counter;

    Pixel_clk_gen U_P_CLK (.*);
    pixel_counter U_P_COUNTER (.*);
    vga_decoder U_VGA_Decoder (.*);
endmodule

/////////////////////////////////////////////////////////////////////

// [수정 1] 안정적인 50% Duty-Cycle 클럭 생성 (예: 100MHz -> 25MHz)
module Pixel_clk_gen (
    input  logic clk,
    input  logic reset,
    output logic pclk
);
    logic [1:0] p_counter;
    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            p_counter <= 0;
        end else begin
            p_counter <= p_counter + 1;
        end
    end
    assign pclk = p_counter[1];  // Divide by 4
endmodule

/////////////////////////////////////////////////////////////////////

// [수정 2] 모든 로직을 'posedge' 기준으로 통일
module pixel_counter (
    input  logic       pclk,
    input  logic       reset,
    output logic [9:0] v_counter,
    output logic [9:0] h_counter
);
    localparam H_MAX = 800, V_MAX = 525;

    always_ff @(posedge pclk, posedge reset) begin  // negedge -> posedge
        if (reset) h_counter <= 0;
        else if (h_counter == H_MAX - 1) h_counter <= 0;
        else h_counter <= h_counter + 1;
    end

    always_ff @(posedge pclk, posedge reset) begin  // negedge -> posedge
        if (reset) v_counter <= 0;
        else if (h_counter == H_MAX - 1) begin
            if (v_counter == V_MAX - 1) v_counter <= 0;
            else v_counter <= v_counter + 1;
        end
    end
endmodule

/////////////////////////////////////////////////////////////////////

module vga_decoder (
    input  logic [9:0] h_counter,
    input  logic [9:0] v_counter,
    input  logic       pclk,
    input  logic       reset,
    output logic       h_sync,
    output logic       v_sync,
    output logic [9:0] x_pixel,
    output logic [9:0] y_pixel,
    output logic       DE
);
    localparam H_Visible_area = 640, H_Front_porch = 16, H_Sync_pulse = 96, H_Back_porch = 48, H_Whole_Line = 800;
    localparam V_Visible_area = 480, V_Front_porch = 10, V_Sync_pulse = 2, V_Back_porch = 33, V_Whole_frame = 525;

    // 요청하신 대로 x_pixel 값 보정 로직을 적용
    assign x_pixel = (h_counter >= 800) ? h_counter - 800 + 1 : h_counter + 1;
    assign y_pixel = v_counter;

    always_ff @(posedge pclk, posedge reset) begin
        if (reset) begin
            h_sync <= 1'b1; 
            v_sync <= 1'b1; 
            DE     <= 1'b0;
        end else begin
            h_sync <= !((h_counter >= (H_Visible_area+H_Front_porch)) && (h_counter <= (H_Visible_area + H_Front_porch + H_Sync_pulse)));
            v_sync <= !((v_counter >= (V_Visible_area+V_Front_porch)) && (v_counter <= (V_Visible_area + V_Front_porch + V_Sync_pulse)));
            DE     <= ((h_counter < H_Visible_area) && (v_counter < V_Visible_area));
        end
    end
endmodule
