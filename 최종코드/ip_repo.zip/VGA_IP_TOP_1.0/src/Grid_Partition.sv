`timescale 1ns / 1ps

module Grid_Partition (
    input  wire       clk,
    input  wire       reset,
    input  wire       v_sync,
    input  wire       DE,
    input  wire       red_glove_detect,
    input  wire [9:0] x_pixel,
    output reg  [2:0] selected_grid      // 0 = 없음, 1~5 = grid
);

    localparam SELECT_GRID_MIN = 500;

    // internal signals
    reg [13:0] Grid [0:4];
    reg [13:0] max_val;
    reg v_sync_delay;

    // delay v_sync
    always_ff @(posedge clk or posedge reset) begin
        if (reset)
            v_sync_delay <= 1'b0;
        else
            v_sync_delay <= v_sync;
    end

    // grid_final 계산 (v_sync 하강 에지에서)
    always_ff @(posedge clk or posedge reset) begin
        if (reset) begin
            selected_grid <= 3'd0;
        end else if (!v_sync && v_sync_delay) begin
            // 최대값 계산
            max_val = Grid[0];
            selected_grid = 3'd1;

            if (Grid[1] > max_val) begin
                max_val = Grid[1];
                selected_grid = 3'd2;
            end
            if (Grid[2] > max_val) begin
                max_val = Grid[2];
                selected_grid = 3'd3;
            end
            if (Grid[3] > max_val) begin
                max_val = Grid[3];
                selected_grid = 3'd4;
            end
            if (Grid[4] > max_val) begin
                max_val = Grid[4];
                selected_grid = 3'd5;
            end

            // 모든 Grid가 최소값 이하이면 장갑 없음
            if (max_val <= SELECT_GRID_MIN)
                selected_grid = 3'd0;
        end
    end

    // Grid 누적
    always_ff @(posedge clk or posedge reset) begin
        if (reset) begin
            Grid[0] <= 0;
            Grid[1] <= 0;
            Grid[2] <= 0;
            Grid[3] <= 0;
            Grid[4] <= 0;
        end else if (v_sync && !v_sync_delay) begin
            // 한 프레임 끝나면 초기화
            Grid[0] <= 0;
            Grid[1] <= 0;
            Grid[2] <= 0;
            Grid[3] <= 0;
            Grid[4] <= 0;
        end else if (DE && red_glove_detect) begin
            case (x_pixel[9:7])
                3'd0: Grid[0] <= Grid[0] + 1;
                3'd1: Grid[1] <= Grid[1] + 1;
                3'd2: Grid[2] <= Grid[2] + 1;
                3'd3: Grid[3] <= Grid[3] + 1;
                3'd4: Grid[4] <= Grid[4] + 1;
                default: ;
            endcase
        end
    end

endmodule
