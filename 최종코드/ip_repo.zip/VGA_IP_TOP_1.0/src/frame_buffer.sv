`timescale 1ns / 1ps

module frame_buffer (
    // write side
    input  wire        wclk,
    input  wire        we,
    input  wire [16:0] wAddr,
    input  wire [15:0] wData,
    // read side
    input  wire        rclk,
    input  wire        oe,
    input  wire [16:0] rAddr,
    output reg  [15:0] rData
);

    // memory declaration
    reg [15:0] mem [0:(320*240-1)];

    // write side
    always @(posedge wclk) begin
        if (we) begin
            mem[wAddr] <= wData;
        end
    end

    // read side
    always @(posedge rclk) begin
        if (oe) begin
            rData <= mem[rAddr];
        end
    end

endmodule
