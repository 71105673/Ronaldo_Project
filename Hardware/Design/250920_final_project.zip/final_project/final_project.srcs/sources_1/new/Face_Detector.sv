`timescale 1ns / 1ps

module Face_Detector (
    input  logic       pclk,
    input  logic       reset,
    input  logic       DE,
    input  logic [3:0] r_in,
    input  logic [3:0] g_in,
    input  logic [3:0] b_in,
    input  logic [9:0] x_pixel,
    input  logic [9:0] y_pixel,
    input  logic       sw_gray,
    output logic [3:0] r_port,
    output logic [3:0] g_port,
    output logic [3:0] b_port,
    output logic [19:0]cen_data
);

    logic [3:0] m_r, m_g, m_b;  // flesh_color 출력(흰/검)
    logic [3:0] sobel_r, sobel_g, sobel_b;  // Sobel 출력(그레이스케일)

    // ====== 엣지 중심 표시 오버레이 ======
    // 오버레이 결과
    logic [3:0] cen_r, cen_g, cen_b;


    // 살색 마스크(흰/검)
    flesh_color U_flesh_c (
        .den  (DE),
        .r_in (r_in),
        .g_in (g_in),
        .b_in (b_in),
        .r_out(m_r),
        .g_out(m_g),
        .b_out(m_b)
    );

    // Sobel (입력은 살색 마스크 영상)
    SobelFilter #(
        .WIDTH(640)
    ) U_SobelFilter (
        .clk  (pclk),
        .rst  (reset),
        .den  (DE),
        .x_in (x_pixel),
        .y_in (y_pixel),
        .r_in (m_r),
        .g_in (m_g),
        .b_in (m_b),
        .r_out(sobel_r),
        .g_out(sobel_g),
        .b_out(sobel_b)
    );

    SkinCentroidMark #(
        .WIDTH(640),
        .HEIGHT(320),
        .MIN_COUNT(800),
        .HLEN(16),
        .VLEN(16),
        .THICK(2)
    ) U_SkinCentroid (
        .clk         (pclk),
        .rst         (reset),
        .den         (DE),         // flesh_color와 동일 정렬
        .x_in        (x_pixel),
        .y_in        (y_pixel),
        .r_in        (sobel_r),
        .g_in        (sobel_g),
        .b_in        (sobel_b),
        .r_out       (cen_r),
        .g_out       (cen_g),
        .b_out       (cen_b),
        .center_data (cen_data)
    );

    // 출력 선택: sw_gray=1 → 십자표시 포함, 0 → 마스크만
    assign {r_port, g_port, b_port} = sw_gray ? {cen_r, cen_g, cen_b}
                                          : {sobel_r,   sobel_g,   sobel_b};

endmodule
