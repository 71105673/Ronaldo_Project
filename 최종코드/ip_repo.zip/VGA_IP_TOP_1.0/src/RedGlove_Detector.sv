`timescale 1ns / 1ps

module RedGlove_Detector (
    input  wire [3:0] r_data,
    input  wire [3:0] g_data,
    input  wire [3:0] b_data,
    output wire       detect
);

    // parameters
    localparam SATURATION = 5; // 7
    localparam DIFFERENCE = 6;

    // internal signals
    wire [3:0] max_val, min_val, delta;

    // 최�?�?, 최소�? 계산
    assign max_val = (r_data >= g_data && r_data >= b_data) ? r_data :
                     (g_data >= b_data) ? g_data : b_data;

    assign min_val = (r_data <= g_data && r_data <= b_data) ? r_data :
                     (g_data <= b_data) ? g_data : b_data;

    assign delta = max_val - min_val;

    // 빨강 �?�? 조건 (?��?��?��)
    // R?�� ?��?�� ?���?, 빨강 ?��분이 충분?�� ?���?, 채도(S)�? ?��?�� ?��?��?�� ?��
    assign detect = (r_data == max_val) && (delta >= SATURATION) &&
                    ((r_data - g_data) >= DIFFERENCE) && ((r_data - b_data) >= DIFFERENCE);

endmodule
