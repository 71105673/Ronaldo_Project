`timescale 1ns / 1ps

module Red_Glove_Grid_Selector (
    input logic pclk,
    input logic reset,
    input logic [3:0] r_in,
    input logic [3:0] g_in,
    input logic [3:0] b_in,
    input logic v_sync,
    input logic DE,
    input logic [9:0] x_pixel,
    output logic [2:0] selected_grid,
    output logic [3:0] r_out,
    output logic [3:0] g_out,
    output logic [3:0] b_out
);

    logic red_glove_detect;

    RedGlove_Detector U_RedGlove_Detector (
        .r_data(r_in),
        .g_data(g_in),
        .b_data(b_in),
        .detect(red_glove_detect)
    );

    Grid_Partition U_Grid_Partition (
        .clk             (pclk),
        .reset           (reset),
        .v_sync          (v_sync),
        .DE              (DE),
        .red_glove_detect(red_glove_detect),
        .x_pixel         (x_pixel),
        .selected_grid   (selected_grid)      // 0 = 없음, 1~5 = grid
    );

    select_grid U_Selected_Grid (
        .DE(DE),
        .selected_grid(selected_grid),  // 0 = 없음, 1~5 = Grid
        .x_pixel(x_pixel),
        .r_in(r_in),
        .g_in(g_in),
        .b_in(b_in),
        .r_out(r_out),
        .g_out(g_out),
        .b_out(b_out)
    );

endmodule
