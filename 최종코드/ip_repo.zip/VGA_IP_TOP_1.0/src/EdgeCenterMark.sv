`timescale 1ns/1ps
module SkinCentroidMark #(
    parameter int WIDTH      = 320,
    parameter int HEIGHT     = 240,
    parameter int MIN_COUNT  = 200, // 최소 픽셀 수(노이즈 제거용)
    parameter int HLEN       = 8,   // 십자 가로 반길이(총 2*HLEN+1)
    parameter int VLEN       = 8,   // 십자 세로 반길이
    parameter int THICK      = 1    // 선 두께(±THICK)
)(
    input  wire        clk,
    input  wire        rst,
    input  wire        den,            // 입력 유효(마스크와 정렬)
    input  wire [9:0]  x_in,           // 0..WIDTH-1
    input  wire [9:0]  y_in,           // 0..HEIGHT-1

    // 살색 마스크 영상 입력(흰/검). 흰(>0)이면 skin으로 간주.
    input  wire [3:0]  r_in,
    input  wire [3:0]  g_in,
    input  wire [3:0]  b_in,

    // 오버레이 결과 출력
    output reg [3:0]  r_out,
    output reg [3:0]  g_out,
    output reg [3:0]  b_out,

    // 디버깅/표시용 중심좌표
    output wire [19:0]  center_data,
    output wire         center_valid
);

    // 프레임/라인 시작 검출
    wire frame_start = den && (x_in==10'd0) && (y_in==10'd0);

    // 누적기 (충분히 여유 있는 폭)
    reg [31:0] sum_x, sum_y;
    reg [31:0] count;

    // 지난 프레임에서 계산된 중심 레지스터(현재 프레임 표시용)
    reg [9:0] cx, cy;
    reg       cvalid;

    // 누적: 현재 프레임
    wire skin = den && ((r_in|g_in|b_in) != 4'd0);

    always @(posedge clk) begin
        if (rst) begin
            sum_x <= 0; sum_y <= 0; count <= 0;
            cx <= 0; cy <= 0; cvalid <= 1'b0;
        end else begin
            // 프레임 시작 시: 지난 프레임 결과 계산 → 래치, 그 후 누적기 클리어
            if (frame_start) begin
                if (count >= MIN_COUNT) begin
                    cx     <= (sum_x / count);
                    cy     <= (sum_y / count);
                    cvalid <= 1'b1;
                end else begin
                    cx     <= 10'd0;
                    cy     <= 10'd0;
                    cvalid <= 1'b0;
                end
                sum_x <= 0;
                sum_y <= 0;
                count <= 0;
            end else if (skin) begin
                // skin 픽셀만 누적
                sum_x <= sum_x + x_in;
                sum_y <= sum_y + y_in;
                count <= count + 1;
            end
        end
    end

    // 외부로도 좌표 제공 (assign 사용)
    assign center_valid = cvalid;
    assign center_data  = cvalid ? {cx, cy} : 20'b0;

    // 십자 표시(빨강) 오버레이
    // 두께 처리: |x-cx|<=THICK 이면 세로선, |y-cy|<=THICK 이면 가로선
    // 길이 제한: [cx-HLEN, cx+HLEN], [cy-VLEN, cy+VLEN] 영역
    function automatic bit in_range(input int v, input int lo, input int hi);
        return (v>=lo) && (v<=hi);
    endfunction

    wire horz_here = cvalid && den
                   && in_range(x_in, cx-HLEN, cx+HLEN)
                   && ( (y_in >= (cy-THICK)) && (y_in <= (cy+THICK)) );

    wire vert_here = cvalid && den
                   && in_range(y_in, cy-VLEN, cy+VLEN)
                   && ( (x_in >= (cx-THICK)) && (x_in <= (cx+THICK)) );

    wire mark_here = horz_here || vert_here;

    always @(posedge clk) begin
        if (rst) begin
            r_out <= 0; g_out <= 0; b_out <= 0;
        end else if (den) begin
            if (mark_here) begin
                r_out <= 4'hF; g_out <= 4'h0; b_out <= 4'h0; // 빨강 십자
            end else begin
                // 배경은 입력 통과(살색 마스크 영상)
                r_out <= r_in; g_out <= g_in; b_out <= b_in;
            end
        end else begin
            r_out <= 0; g_out <= 0; b_out <= 0;
        end
    end

endmodule
