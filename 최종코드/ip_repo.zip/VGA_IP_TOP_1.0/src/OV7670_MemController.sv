`timescale 1ns / 1ps

module OV7670_MemController (
    input  wire        clk,
    input  wire        reset,
    // ov7670 side
    input  wire        href,
    input  wire        vsync,
    input  wire [ 7:0] ov7670_data,
    // memory side
    output reg         we,
    output wire [16:0] wAddr,
    output wire [15:0] wData
);

    reg [15:0] pixel_data;
    reg [ 9:0] h_counter;   // 320 * 2 = 640 (320 pixel) -> 2byte 묶어?�� ?��보내�? ?��?�� 320 * 2
    reg [ 7:0] v_counter;   // 240 line

    assign wAddr = v_counter * 320 + h_counter[9:1] - 1;
    assign wData = pixel_data;

    // ?��?�� ?��?? 카운?�� �? write enable ?��?��
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            h_counter  <= 10'd0;
            pixel_data <= 16'd0;
            we         <= 1'b0;
        end else begin
            if (href) begin
                h_counter <= h_counter + 1'b1;
                if (h_counter[0] == 1'b0) begin
                    pixel_data[15:8] <= ov7670_data;
                    we               <= 1'b0;
                end else begin
                    pixel_data[7:0] <= ov7670_data;
                    we              <= 1'b1;
                end
            end else begin
                h_counter <= 10'd0;
                we        <= 1'b0;
            end
        end
    end

    // ?���? ?��?�� 카운?��
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            v_counter <= 8'd0;
        end else begin
            if (vsync) begin
                v_counter <= 8'd0;
            end else begin
                if (h_counter == (320 * 2 - 1)) begin
                    v_counter <= v_counter + 1'b1;
                end
            end
        end
    end

endmodule
