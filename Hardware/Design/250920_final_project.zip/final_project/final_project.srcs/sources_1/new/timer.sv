`timescale 1ns / 1ps

module timer (
    input  logic       clk,
    input  logic       reset,
    input  logic       en,
    input  logic [3:0] in_count_value,
    output logic [3:0] out_count_value
);

    logic tick_1khz, tick_1sec;
    logic [3:0] value;
    logic [$clog2(1000)-1:0] sec_counter;

    tick_counter_1khz U_Tick_CNT (.*);

    assign out_count_value = value;

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            value <= 0;
        end else begin
            if (en) begin
                value <= in_count_value;
            end else if (tick_1sec && (value != 0)) begin
                value <= value - 1;
            end
        end
    end

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            sec_counter <= 0;
            tick_1sec   <= 1'b0;
        end else begin
            if (tick_1khz) begin
                if (sec_counter == 1000 - 1) begin
                    sec_counter <= 0;
                    tick_1sec   <= 1'b1;
                end else begin
                    sec_counter <= sec_counter + 1;
                    tick_1sec   <= 1'b0;
                end
            end
        end
    end

endmodule

module tick_counter_1khz (
    input  logic clk,
    input  logic reset,
    output logic tick_1khz
);

    logic [$clog2(100_000)-1:0] tick_counter;

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            tick_counter <= 0;
            tick_1khz    <= 1'b0;
        end else begin
            if (tick_counter == 100_000) begin
                tick_counter <= 0;
                tick_1khz    <= 1'b1;
            end else begin
                tick_counter <= tick_counter + 1;
                tick_1khz    <= 1'b0;
            end
        end
    end

endmodule
