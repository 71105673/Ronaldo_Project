`timescale 1ns / 1ps

module uart_intf (
    input  logic         clk,
    input  logic         reset,
    input  logic [ 2:0]  grid_data,
    input  logic [ 2:0]  kick_data,
    input  logic [19:0]  face_data,
    input  logic         rx,
    output logic         tx
);

    logic start, tx_busy, tx_done;
    logic rx_done;
    logic [7:0] tx_data, rx_data;
    logic [7:0] push_data;
    logic empty, full, push;

    logic [ 2:0] grid_data_reg;
    logic [19:0] face_data_reg;
    logic [ 1:0] face_data_cnt;
    logic [ 2:0] kick_data_reg;

    logic [2:0] CR;

    logic [2:0] header;
    assign header = rx_data[7:5];

    typedef enum {
        IDLE,
        SEND_GRID,
        SEND_FACE,
        SEND_KICK
    } state_e;

    state_e state, next_state;

    always_comb begin
        CR = 3'b000;
        if (rx_done) begin
            case (header)
                3'b001: CR = 1; // grid
                3'b010: CR = 2; // face
                3'b011: CR = 3; // kickl
                default: CR = 0;
            endcase
        end
    end

    always_ff @(posedge clk or posedge reset) begin
        if (reset) begin
            state <= IDLE;
            grid_data_reg <= 3'b0;
            face_data_reg <= 20'b0;
            kick_data_reg <= 3'b0;
            face_data_cnt <= 2'b0;
        end else begin
            state <= next_state;
            
            if (next_state == SEND_GRID) begin
                grid_data_reg <= grid_data;
            end
            if (next_state == SEND_FACE) begin
                face_data_reg <= face_data;
            end
            if (next_state == SEND_KICK) begin
                kick_data_reg <= kick_data;
            end

            if (state == SEND_FACE && next_state == SEND_FACE) begin
                if (!full) begin
                    face_data_cnt <= face_data_cnt + 1;
                end
            end else begin
                face_data_cnt <= 2'b0;
            end
        end
    end

    always_comb begin
        next_state = state;
        push       = 1'b0;
        push_data  = 8'h00;
        case (state)
            IDLE: begin
                if (CR == 2) begin
                    if (!full) begin
                        next_state = SEND_FACE;
                    end
                end else if (CR == 1 || (grid_data_reg != grid_data)) begin
                    if (!full) begin
                        next_state = SEND_GRID;
                    end
                end else if (CR == 3) begin
                    if (!full) begin
                        next_state = SEND_KICK;
                    end
                end
            end

            SEND_GRID: begin
                push = 1'b1;
                push_data = {5'b00000, grid_data_reg};

                if (rx_done && header == 3'b000) begin 
                    next_state = IDLE;
                end else begin
                    next_state = SEND_GRID;
                end
            end

            SEND_FACE: begin
                push = 1'b1;
                case (face_data_cnt)
                    2'd0: push_data = {3'b010, face_data_reg[19:15]};
                    2'd1: push_data = {3'b010, face_data_reg[14:10]};
                    2'd2: push_data = {3'b010, face_data_reg[ 9:5]};
                    2'd3: push_data = {3'b010, face_data_reg[ 4:0]};
                endcase
        
                if (rx_done && header == 3'b000) begin
                    next_state = IDLE;
                end else begin
                    next_state = SEND_FACE;
                end
            end             
            SEND_KICK: begin
                push = 1'b1;
                push_data = {5'b00000, kick_data_reg};
                next_state = IDLE;
            end
        endcase
    end

    uart U_UART (
        .clk     (clk),
        .reset   (reset),
        .start   (start),
        .tx_data (tx_data),
        .rx      (rx),
        .tx_busy (tx_busy),
        .tx_done (tx_done),
        .tx      (tx),
        .rx_busy (),
        .rx_done (rx_done),
        .rx_data (rx_data)
    );

    fifo tx_fifo (
        .clk       (clk),
        .reset     (reset),
        .push_data (push_data),
        .push      (push),
        .valid     (start),
        .pop_data  (tx_data),
        .pop       (!tx_busy && !empty),
        .empty     (empty),
        .full      (full)
    );

endmodule

module fifo (
    input  logic       clk,
    input  logic       reset,
    input  logic [7:0] push_data,
    input  logic       push,
    output logic       valid,
    output logic [7:0] pop_data,
    input  logic       pop,
    output logic       empty,
    output logic       full
);

    logic [7:0] mem[0:3];
    logic [1:0] front, rear;

    assign empty = (front == rear);
    assign full  = ((front + 1) == rear);

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            mem[0] <= 0;
            mem[1] <= 0;
            mem[2] <= 0;
            mem[3] <= 0;
            front <= 0;
            rear <= 0;
            pop_data <= 0;
        end else begin
            valid <= 1'b0;
            if (push && !full) begin
                mem[front] <= push_data;
                front <= front + 1;
            end

            if (pop && !empty) begin
                pop_data <= mem[rear];
                rear <= rear + 1;
                valid <= 1'b1;
            end
        end
    end

endmodule

module uart (
    input  logic       clk,
    input  logic       reset,
    input  logic       start,
    input  logic [7:0] tx_data,
    input  logic       rx,
    output logic       tx_busy,
    output logic       tx_done,
    output logic       tx,
    output logic       rx_busy,
    output logic       rx_done,
    output logic [7:0] rx_data
);

    logic br_tick;

    baudrate_gen U_BAUD_GEN (
        .clk    (clk),
        .reset  (reset),
        .br_tick(br_tick)
    );

    transmitter U_Transmitter (
        .clk    (clk),
        .reset  (reset),
        .br_tick(br_tick),
        .start  (start),
        .tx_data(tx_data),
        .tx_busy(tx_busy),
        .tx_done(tx_done),
        .tx     (tx)
    );

    receiver U_Receiver (
        .clk(clk),
        .reset(reset),
        .br_tick(br_tick),
        .rx(rx),
        .rx_busy(rx_busy),
        .rx_done(rx_done),
        .rx_data(rx_data)
    );

endmodule

module baudrate_gen (
    input  logic clk,
    input  logic reset,
    output logic br_tick
);

    logic [$clog2(100_000_000 / 9600 / 16)-1:0] br_counter;
    //logic [3:0] br_counter;  //simulation

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            br_counter <= 0;
            br_tick    <= 1'b0;
        end else begin
            if (br_counter == 100_000_000 / 9600 / 16 - 1) begin
                //if (br_counter == 10 - 1) begin  //simulation
                br_counter <= 0;
                br_tick <= 1'b1;
            end else begin
                br_counter <= br_counter + 1;
                br_tick <= 1'b0;
            end
        end
    end

endmodule

module transmitter (
    input  logic       clk,
    input  logic       reset,
    input  logic       br_tick,
    input  logic       start,
    input  logic [7:0] tx_data,
    output logic       tx_busy,
    output logic       tx_done,
    output logic       tx
);

    typedef enum {
        IDLE,
        START,
        DATA,
        STOP
    } tx_state_e;

    tx_state_e tx_state, tx_next_state;

    logic [7:0] temp_data_reg, temp_data_next;
    logic tx_reg, tx_next;
    logic [3:0] tick_cnt_reg, tick_cnt_next;
    logic [2:0] bit_cnt_reg, bit_cnt_next;
    logic tx_done_reg, tx_done_next;
    logic tx_busy_reg, tx_busy_next;

    assign tx = tx_reg;
    assign tx_busy = tx_busy_reg;
    assign tx_done = tx_done_reg;

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            tx_state      <= IDLE;
            temp_data_reg <= 0;
            tx_reg        <= 1'b1;
            tick_cnt_reg  <= 0;
            bit_cnt_reg   <= 0;
            tx_done_reg   <= 0;
            tx_busy_reg   <= 0;
        end else begin
            tx_state      <= tx_next_state;
            temp_data_reg <= temp_data_next;
            tx_reg        <= tx_next;
            tick_cnt_reg  <= tick_cnt_next;
            bit_cnt_reg   <= bit_cnt_next;
            tx_done_reg   <= tx_done_next;
            tx_busy_reg   <= tx_busy_next;
        end
    end

    always_comb begin
        tx_next_state = tx_state;
        temp_data_next = temp_data_reg; //latch 방지를 위해 reg, next 형태로 사용
        tx_next = tx_reg;
        tick_cnt_next = tick_cnt_reg;
        bit_cnt_next = bit_cnt_reg;
        tx_done_next = tx_done_reg;
        tx_busy_next = tx_busy_reg;
        case (tx_state)
            IDLE: begin
                tx_next = 1'b1;
                tx_done_next = 0;
                tx_busy_next = 0;
                if (start) begin
                    tx_next_state  = START;
                    temp_data_next = tx_data;
                    tick_cnt_next  = 0;
                    bit_cnt_next   = 0;
                    tx_busy_next   = 1;
                end
            end
            START: begin
                tx_next = 1'b0;
                if (br_tick) begin
                    if (tick_cnt_reg == 15) begin
                        tx_next_state = DATA;
                        tick_cnt_next = 0;
                    end else begin
                        tick_cnt_next = tick_cnt_reg + 1;
                    end
                end
            end
            DATA: begin
                tx_next = temp_data_reg[0];
                if (br_tick) begin
                    if (tick_cnt_reg == 15) begin
                        tick_cnt_next = 0;
                        if (bit_cnt_reg == 7) begin
                            tx_next_state = STOP;
                            bit_cnt_next  = 0;
                        end else begin
                            temp_data_next = {
                                1'b0, temp_data_reg[7:1]
                            };  //하나씩 0bit 것을 보내면서 shift
                            bit_cnt_next = bit_cnt_reg + 1;
                        end
                    end else begin
                        tick_cnt_next = tick_cnt_reg + 1;
                    end
                end
            end
            STOP: begin
                tx_next = 1'b1;
                if (br_tick) begin
                    if (tick_cnt_reg == 15) begin
                        tx_next_state = IDLE;
                        tx_done_next  = 1;
                        tx_busy_next  = 0;
                        tick_cnt_next = 0;
                    end else begin
                        tick_cnt_next = tick_cnt_reg + 1;
                    end
                end
            end
        endcase
    end

endmodule

module receiver (
    input  logic       clk,
    input  logic       reset,
    input  logic       br_tick,
    input  logic       rx,
    output logic       rx_busy,
    output logic       rx_done,
    output logic [7:0] rx_data
);

    typedef enum {
        IDLE,
        START,
        DATA,
        STOP
    } rx_state_e;

    rx_state_e rx_state, rx_next_state;

    logic [7:0] temp_data_reg, temp_data_next;
    logic [7:0] rx_reg, rx_next;
    logic [4:0] tick_cnt_reg, tick_cnt_next;
    logic [2:0] bit_cnt_reg, bit_cnt_next;
    logic rx_done_reg, rx_done_next;
    logic rx_busy_reg, rx_busy_next;

    assign rx_data = rx_reg;
    assign rx_busy = rx_busy_reg;
    assign rx_done = rx_done_reg;

    always_ff @(posedge clk, posedge reset) begin
        if (reset) begin
            rx_state      <= IDLE;
            rx_reg        <= 0;
            temp_data_reg <= 0;
            tick_cnt_reg  <= 0;
            bit_cnt_reg   <= 0;
            rx_done_reg   <= 0;
            rx_busy_reg   <= 0;
        end else begin
            rx_state      <= rx_next_state;
            rx_reg        <= rx_next;
            temp_data_reg <= temp_data_next;
            tick_cnt_reg  <= tick_cnt_next;
            bit_cnt_reg   <= bit_cnt_next;
            rx_done_reg   <= rx_done_next;
            rx_busy_reg   <= rx_busy_next;
        end
    end

    always_comb begin
        rx_next_state  = rx_state;
        rx_next        = rx_reg;
        temp_data_next = temp_data_reg;
        tick_cnt_next  = tick_cnt_reg;
        bit_cnt_next   = bit_cnt_reg;
        rx_done_next   = rx_done_reg;
        rx_busy_next   = rx_busy_reg;
        case (rx_state)
            IDLE: begin
                rx_busy_next = 0;
                rx_done_next = 0;
                if (~rx) begin
                    rx_next_state  = START;
                    temp_data_next = 0;
                    tick_cnt_next  = 0;
                    bit_cnt_next   = 0;
                    rx_busy_next   = 1;
                    rx_next        = 0;
                end
            end
            START: begin
                if (br_tick) begin
                    if (tick_cnt_reg == 7) begin
                        rx_next_state = DATA;
                        tick_cnt_next = 0;
                    end else begin
                        tick_cnt_next = tick_cnt_next + 1;
                    end
                end
            end
            DATA: begin
                if (br_tick) begin
                    if (tick_cnt_reg == 15) begin
                        temp_data_next = {rx, temp_data_reg[7:1]};
                        tick_cnt_next  = 0;
                        if (bit_cnt_reg == 7) begin
                            rx_next_state = STOP;
                            bit_cnt_next  = 0;
                        end else begin
                            bit_cnt_next = bit_cnt_next + 1;
                        end
                    end else begin
                        tick_cnt_next = tick_cnt_next + 1;
                    end
                end
            end
            STOP: begin
                if (br_tick) begin
                    if (tick_cnt_reg == 23) begin
                        rx_next_state = IDLE;
                        tick_cnt_next = 0;
                        rx_busy_next  = 0;
                        rx_done_next  = 1;
                        rx_next       = temp_data_reg;
                    end else begin
                        tick_cnt_next = tick_cnt_next + 1;
                    end
                end
            end
        endcase
    end

endmodule
