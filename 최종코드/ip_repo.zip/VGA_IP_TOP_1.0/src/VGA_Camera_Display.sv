`timescale 1ns / 1ps

module VGA_Camera_Display (
    input  wire       clk,
    input  wire       reset,
    input  wire [1:0] sw_mode,
    
    // ov7670 side
    output wire       ov7670_xclk,
    input  wire       ov7670_pclk,
    input  wire       ov7670_href,
    input  wire       ov7670_vsync,
    input  wire [7:0] ov7670_data,

    // external port
    output wire       h_sync,
    output wire       v_sync,
    output wire [3:0] r_port,
    output wire [3:0] g_port,
    output wire [3:0] b_port,
    // slave reg
    output wire [19:0] cen_data,
    output wire [ 2:0] selected_grid
);

    wire        ov7670_we;
    wire [16:0] ov7670_wAddr;
    wire [15:0] ov7670_wData;

    wire        vga_pclk;
    wire [ 9:0] vga_x_pixel;
    wire [ 9:0] vga_y_pixel;
    wire        vga_DE;

    wire        vga_den;
    wire [16:0] vga_rAddr;
    wire [15:0] vga_rData;

    wire [ 3:0] vga_r;
    wire [ 3:0] vga_g;
    wire [ 3:0] vga_b;

    wire [ 4:0] vga_r_rom;
    wire [ 5:0] vga_g_rom;
    wire [ 4:0] vga_b_rom;

    wire [ 3:0] gray_r;
    wire [ 3:0] gray_g;
    wire [ 3:0] gray_b;

    wire [ 3:0] face_detected_r;
    wire [ 3:0] face_detected_g;
    wire [ 3:0] face_detected_b;

    wire [ 3:0] grid_r, grid_g, grid_b;

    wire [ 3:0] img_r, img_g, img_b;
    wire [ 3:0] r_port_m4, g_port_m4, b_port_m4;

    wire        green;
    wire [11:0] cam_rgb, rom_rgb, vga_rgb;

    assign ov7670_xclk = vga_pclk;

    VGA_Decoder U_VGA_Decoder (
        .clk    (clk),
        .reset  (reset),
        .pclk   (vga_pclk),
        .h_sync (h_sync),
        .v_sync (v_sync),
        .x_pixel(vga_x_pixel),
        .y_pixel(vga_y_pixel),
        .DE     (vga_DE)
    );

    OV7670_MemController U_OV7670_MemController (
        .clk        (ov7670_pclk),
        .reset      (reset),
        .href       (ov7670_href),
        .vsync      (ov7670_vsync),
        .ov7670_data(ov7670_data),
        .we         (ov7670_we),
        .wAddr      (ov7670_wAddr),
        .wData      (ov7670_wData)
    );

    frame_buffer U_FrameBuffer (
        .wclk (ov7670_pclk),
        .we   (ov7670_we),
        .wAddr(ov7670_wAddr),
        .wData(ov7670_wData),
        .rclk (vga_pclk),
        .oe   (vga_den),
        .rAddr(vga_rAddr),
        .rData(vga_rData)
    );

    VGA_MemController U_VGAMemController (
        .DE     (vga_DE),
        .x_pixel(vga_x_pixel),
        .y_pixel(vga_y_pixel),
        .den    (vga_den),
        .rAddr  (vga_rAddr),
        .rData  (vga_rData),
        .r_port (vga_r),
        .g_port (vga_g),
        .b_port (vga_b),
        .r_port_rom(vga_r_rom),
        .g_port_rom(vga_g_rom),
        .b_port_rom(vga_b_rom)
    );

    GrayScaleFilter U_GRAY (
        .i_r(vga_r),
        .i_g(vga_g),
        .i_b(vga_b),
        .o_r(gray_r),
        .o_g(gray_g),
        .o_b(gray_b)
    );

    Red_Glove_Grid_Selector U_Red_Glove_Grid_Selector (
        .pclk         (vga_pclk),
        .reset        (reset),
        .r_in         (vga_r),
        .g_in         (vga_g),
        .b_in         (vga_b),
        .v_sync       (v_sync),
        .DE           (vga_den),
        .x_pixel      (vga_x_pixel),
        .selected_grid(selected_grid),
        .r_out        (grid_r),
        .g_out        (grid_g),
        .b_out        (grid_b)
    );

    Face_Detector U_Face_Detector (
        .pclk(vga_pclk),
        .reset(reset),
        .DE(vga_den),
        .r_in(vga_r),
        .g_in(vga_g),
        .b_in(vga_b),
        .x_pixel(vga_x_pixel),
        .y_pixel(vga_y_pixel),
        .sw_gray(sw_gray),
        .r_port(face_detected_r),
        .g_port(face_detected_g),
        .b_port(face_detected_b),
        .cen_data(cen_data)
    );

    mux_4x1 U_MUX (
        .sel         (sw_mode),
        .vga_rgb     ({vga_r, vga_g, vga_b}),
        .gray_rgb    ({gray_r, gray_g, gray_b}),
        .redglove_rgb({grid_r, grid_g, grid_b}),
        .face_detected_rgb({face_detected_r, face_detected_g, face_detected_b}),
        .rgb         ({r_port_m4, g_port_m4, b_port_m4})
    );

    Chromakey_Filter U_Chromakey_Filter (
        .DE     (vga_DE),
        .x      (vga_x_pixel),
        .y      (vga_y_pixel),
        .i_r    (vga_r_rom),
        .i_g    (vga_g_rom),
        .i_b    (vga_b_rom),
        .green  (green),
        .r_port (img_r),
        .g_port (img_g),
        .b_port (img_b)
    );

    assign cam_rgb = {r_port_m4, g_port_m4, b_port_m4};
    assign rom_rgb = {img_r, img_g, img_b};

    mux_2x1 U_MUX_2x1 (
        .sel     (green),
        .cam_rgb (cam_rgb),
        .rom_rgb (rom_rgb),
        .vga_rgb (vga_rgb)
    );

    assign {r_port, g_port, b_port} = vga_rgb;

endmodule

module mux_4x1 (
    input  wire [ 1:0] sel,
    input  wire [11:0] vga_rgb,
    input  wire [11:0] gray_rgb,
    input  wire [11:0] redglove_rgb,
    input  wire [11:0] face_detected_rgb,
    output reg  [11:0] rgb
);

    always @(*) begin
        case (sel)
            2'b00: rgb = vga_rgb;
            2'b01: rgb = gray_rgb;
            2'b10: rgb = redglove_rgb;
            2'b11: rgb = face_detected_rgb;
            default: rgb = vga_rgb;
        endcase
    end

endmodule

module mux_2x1 (
    input  wire        sel,
    input  wire [11:0] cam_rgb,
    input  wire [11:0] rom_rgb,
    output reg  [11:0] vga_rgb
);
    always @(*) begin
        case (sel)
            1'b0: vga_rgb = cam_rgb;
            1'b1: vga_rgb = rom_rgb;
        endcase
    end
endmodule
